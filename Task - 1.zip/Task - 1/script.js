// JavaScript for temperature conversion
const unitSelector = document.getElementById('unit');
const temperatureInput = document.getElementById('temperature');
const resultOutput = document.getElementById('result');
const convertButton = document.getElementById('convertButton');

function convertTemperature() {
    const selectedUnit = unitSelector.value;
    const temperature = parseFloat(temperatureInput.value);

    if (isNaN(temperature)) {
        resultOutput.textContent = 'Please enter a valid number.';
        return;
    }

    let convertedTemperature;
    if (selectedUnit === 'celsius') {
        convertedTemperature = (temperature * 9/5) + 32; // Celsius to Fahrenheit
    } else if (selectedUnit === 'fahrenheit') {
        convertedTemperature = (temperature - 32) * 5/9; // Fahrenheit to Celsius
    } else if (selectedUnit === 'kelvin') {
        convertedTemperature = temperature - 273.15; // Kelvin to Celsius
    }

    resultOutput.textContent = `Converted temperature: ${convertedTemperature.toFixed(2)} ${selectedUnit}`;
}

// Add an event listener to update the conversion when the button is clicked
convertButton.addEventListener('click', convertTemperature);

// Initial conversion
convertTemperature();
